import React, {useState,useEffect} from 'react';
import {getSingleLog } from '../../actions/logAction';
import {connect} from 'react-redux';

const EditLogs = ({getSingleLog, log: {singleLog,loading}, ...props})=>{
  
    const [message, setMessage] = useState(singleLog.message);
  const [attention, setAttention] = useState(false);
  const [tech, setTech] = useState(null);
//   const [id, setId] = useState(null);
    

console.log(props);
console.log(singleLog);


useEffect(()=>{
    console.log(singleLog);
        getSingleLog(props.match.params.id)
        console.log(getSingleLog);
        
        // setTimeout(()=>{
        //     if(singleLog!= undefined){
        //         setMessage({ messsage: singleLog.message })
        //         setAttention({ attention: singleLog.attention })
        //         setTech({ tech: singleLog.tech })            
        //     }
        // },4000)
        console.log(message)
        }, [])
        

const onSubmitHandler =()=>{

}

const onChangeHandler = () =>{

}

return(

    <div className = 'container'>

<form onSubmit={onSubmitHandler} className="col s12">

<div className="row">
  <div className="input-field col s6">
    <input name="message" type="text" data-length="10"
      value = {message} />
    <label for="Message">Message</label>
  </div>
</div>

<div className="row">
  <div className="input-field col s6">
    <input name="attention" type="text" data-length="10"
      value = {attention} />
    <label for="Attention">Attention</label>
  </div>
</div>

<div className="row">
  <div className="input-field col s6">
    <input name="tech" type="text" data-length="10"
      value = {tech} />
    <label for="Tech">Tech</label>
  </div>
</div>
</form>

</div>
) 


}

const mapStateToProps = (state) => {
    console.log(state)
    return{
    log:state.log
    } 
 }


export default connect(mapStateToProps, {getSingleLog})(EditLogs);