export const GET_LOGS = 'GET_LOGS';
export const ADD_LOGS = 'ADD_LOGS';
export const SET_LOADING = 'SET_LOADING';
export const ERROR_LOGS = 'ERROR_LOGS';
export const GET_TECHS = 'GET_TECHS';
export const ADD_TECHS = 'ADD_TECHS';
export const DELETE_LOGS = 'DELETE_LOGS';
export const DELETE_TECHS = 'DELETE_TECHS';

