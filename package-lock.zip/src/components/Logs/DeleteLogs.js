import React from 'react';

const DeleteLogs = () =>{
    return(<>
        Delete logs
        </>
    )
}

export default DeleteLogs