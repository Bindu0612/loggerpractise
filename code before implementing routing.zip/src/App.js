import React, {useEffect} from 'react';
import 'materialize-css/dist/css/materialize.min.css';
import M from  "materialize-css/dist/js/materialize.min.js";
import Searchbar from './components/Layouts/Searchbar';
import Logs from './components/Logs/Logs';


const App = () =>{
  useEffect(()=>{
    M.AutoInit();
  })

  return(
    <>
    <Searchbar/>
   <Logs/>
   
    </>
  )
}

export default App;