import React, {Component} from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import App from './App';
import store from './store';
import {Provider} from 'react-redux';
import { Route, BrowserRouter as Router } from 'react-router-dom';
import AddLogs from './components/Logs/AddLogs';  

class Routing extends Component{
render(){
  return(<div>
    <Router>
    <Route exact path="/" component={App} />
    <Route exact path="/AddLogs" component={AddLogs} />
</Router>
</div>
  )
}
}



ReactDOM.render(<Provider store = {store}>
 <Routing/>  </Provider> ,
  document.getElementById('root')
);

