import {GET_LOGS, ADD_LOG, SET_LOADING, ERROR_LOGS} from './types';

export const getLogs = ()=>
    async dispatch =>{
        try{
            setLoading();
            console.log("getlogs Api");
            const result = await fetch ( "http://localhost:5000/logs" );
            const data = await result.json();
            dispatch ({
            type : GET_LOGS ,
            preload : data
        })
        }
        catch(err){
            dispatch({
                type : ERROR_LOGS,
                preload : err.data.result
            })
        }

        
        
    }
    export const setLoading =()=>{
        return {
            type : SET_LOADING
        }
    }