export const GET_LOGS = 'GET_LOGS';
export const ADD_LOG = 'ADD_LOG';
export const SET_LOADING = 'SET_LOADING';
export const ERROR_LOGS = 'ERROR_LOGS';
