import React from 'react';

const Searchbar = ()=>{
  
  return(
      <>
           <nav className = "blue">
  <div className="nav-wrapper row ">
    {/* <a href="#" className="brand-logo col s2"> My Logs </a> */}
    <ul id="nav-mobile" className="hide-on-med-and-down col s8">
    <input type = "text"/>
    </ul>

    <ul id="nav-mobile" className="hide-on-med-and-down col s4">
    <li><a href="AddLogs">Add Logs</a></li>
    </ul>

  </div>
</nav>
      </>
  )
}

export default Searchbar;