import React from 'react';
import { withRouter } from 'react-router-dom';

const AddLogs = () =>{
    return(
        <>
        Add logs from here
        </>
    )
}

export default withRouter(AddLogs);